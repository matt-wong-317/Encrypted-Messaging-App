# Messaging App

Members: Kseniya Kolokolkina, Kabishan Sutharman, Matthew Wong, Jason Guan, Nolan Tsang
